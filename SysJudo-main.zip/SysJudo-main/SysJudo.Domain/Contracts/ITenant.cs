﻿namespace SysJudo.Domain.Contracts;

public interface ITenant
{
    public int ClienteId { get; set; }
}