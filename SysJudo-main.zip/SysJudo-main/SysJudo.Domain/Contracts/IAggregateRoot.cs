﻿namespace SysJudo.Domain.Contracts;

public interface IAggregateRoot
{
    
}