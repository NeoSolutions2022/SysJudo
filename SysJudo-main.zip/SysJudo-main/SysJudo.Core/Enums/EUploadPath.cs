﻿using System.ComponentModel;

namespace SysJudo.Core.Enums;

public enum EUploadPath
{
    [Description("fotos_agremiacao")] FotosAgremiacao,

    [Description("fotos_atleta")] FotosAtleta
}