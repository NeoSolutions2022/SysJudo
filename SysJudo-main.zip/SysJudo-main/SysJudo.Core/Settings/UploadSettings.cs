﻿namespace SysJudo.Core.Settings;

public class UploadSettings
{
    public string PublicBasePath { get; set; } = string.Empty;
    public string PrivateBasePath { get; set; } = string.Empty;

}