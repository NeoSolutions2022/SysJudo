namespace SysJudo.Application.Dto.Agremiacao;

public class AnotarAgremiacaoDto
{
    public string Anotacoes { get; set; }
}