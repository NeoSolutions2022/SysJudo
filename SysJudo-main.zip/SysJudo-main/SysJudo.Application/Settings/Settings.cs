﻿namespace SysJudo.Application.Settings;

public static class Settings
{
    public static string Secret = "sfdfvksvfkdvblksvdvav";
}